// EmQuantAPISample.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#include <windows.h>
#include "EmQuantAPI.h"

#include <sstream>
#include <iostream>
#include <string>
#include <deque>
#include <vector>
#include <conio.h>

using namespace std;

// ʹ�þ�̬���ӷ�ʽ
// #ifdef _WIN64  
// #pragma comment(lib,"EmQuantAPI_x64.lib")  
// #else  
// #pragma comment(lib,"EmQuantAPI.lib")  
// #endif  

//���庯��ָ�� ��̬����dll//////////////////////////////////////////////////////////////////////////////
typedef EQErr (*pmanualactivate)(const char* userName, const char* password, const char* options, const char* configDir, logcallback pfnCallback, EQLogLevel eLogLevel);
typedef EQErr (*psetproxy)(ProxyType type, const char* proxyip, unsigned short proxyport, bool verify, const char* proxyuser, const char* proxypwd);
typedef EQErr (*pstart)(const char* options, datacallback mainCallback, const char* configDir, logcallback pfnCallback, EQLogLevel eLogLevel);
typedef EQErr (*pstop)();
typedef const char* (*pgeterrstring)(EQErr errcode, EQLang lang);
typedef EQErr (*pcsd)(const char* codes, const char* indicators, const char* startdate, const char* enddate, const char* options, EQDATA*& eqdata);
typedef EQErr (*pcss)(const char* codes, const char* indicators, const char* options, EQDATA*& pEQData);
typedef EQErr (*ptradedates)(const char* startdate, const char* enddate, const char* options, EQDATA*& pEQData);
typedef EQErr (*psector)(const char* pukeyCode, const char* tradeDate, const char* options, EQDATA*& pEQData);
typedef EQErr (*pgetdate)(const char* tradeDate, int offDay, const char* options, EQDATA*& pEQData);
typedef EQID  (*pcsq)(const char* codes, const char* indicators, const char* options, datacallback pfnCallback, LPVOID lpUserParam);
typedef EQErr (*pcsqcancel)(EQID serialID);
typedef EQErr (*preleasedata)(void* pEqData);
typedef EQErr (*pcsc)(const char* code, const char* indicators, const char* startDate, const char* endDate, const char* options, EQDATA*& pEQData);
typedef EQID  (*pcst)(const char* codes, const char* indicators, const char* startdatetime, const char* enddatetime, const char* options, datacallback pfnCallback, LPVOID lpUserParam);
typedef EQErr (*pctr)(const char* ctrName, const char* indicators, const char* options, EQCTRDATA*& pEQCtrData);
typedef EQErr (*pcsqsnapshot)(const char* codes, const char* indicators, const char* options, EQDATA*& pEQData);
typedef EQErr (*pcps)(const char* cpsCodes, const char* cpsIndicators, const char* cpsConditions, const char* cpsOptions, EQDATA*& pEQData);
typedef EQErr (*ppquery)(const char* options, EQDATA*& pEQData);
typedef EQErr (*pporder)(ORDERINFO* pOrderInfo, int orderInfoSize, const char* accountId, const char* remark, const char* options);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
pmanualactivate   emmanualactivate = NULL;
psetproxy         emsetproxy = NULL;
pstart        emstart = NULL;
pstop         emstop = NULL;
pgeterrstring emgeterrstring = NULL;
pcsd          emcsd = NULL;
pcss          emcss = NULL;
ptradedates   emtradedates = NULL;
psector       emsector = NULL;
pgetdate      emgetdate = NULL;
pcsq          emcsq = NULL;
pcsqcancel    emcsqcancel = NULL;
preleasedata  emreleasedata = NULL;
pcsc          emcsc = NULL;
pcst          emcst = NULL;
pctr          emctr = NULL;
pcsqsnapshot  emcsqsnapshot = NULL;
pcps          emcps = NULL;
ppquery       empquery = NULL;
pporder       emporder = NULL;
//תstring����ʾ��
template<typename T>
std::string to_str(const T &v)
{
	stringstream s;
	s << v;
	return s.str();
}

//��־�ص�����ʾ��
int write2Log(const char* log, EQLogLevel eLogLevel)
{
	switch(eLogLevel)
	{
	case eLog_Debug:
		//printf("this is debug log.\n");
		break;
	case eLog_Info:
		//printf("this is info log.\n");
		break;
	case eLog_Error:
		//printf("this is error log.\n");
		break;
	default:
		break;
	}
	printf("%s", log);
	return 0;
}

//ȡEQVARIENTֵʾ��
std::string eqvalue2string(const EQVARIENT* pEQVarient)
{
	if(!pEQVarient)
	{
		return "";
	}

	char z[1024] = {0};
	std::string s = "";
	switch(pEQVarient->vtype)
	{
		//����Ϊ��������ڹ۲죬�����ַ������޶�������ʵ�ʿɲο�������
	case eVT_null:
		sprintf_s(z,"%s", "        --");
		s = z;
		break;
	case eVT_char:
		sprintf_s(z,"%c", pEQVarient->unionValues.charValue);
		s = z;
		break; 
	case eVT_bool:
		sprintf_s(z,"%c", pEQVarient->unionValues.boolValue ? "true" : "false");
		s = z;
		break;
	case eVT_int:
		sprintf_s(z,"%10d", pEQVarient->unionValues.intValue);
		s = z;
		break;
	case eVT_uInt:
		sprintf_s(z,"%10u", pEQVarient->unionValues.uIntValue);
		s = z;
		break;
	case eVT_int64: 
		sprintf_s(z,"%10I64d", pEQVarient->unionValues.int64Value);
		s = z;
		break;
	case eVT_uInt64: 
		sprintf_s(z,"%10I64u", pEQVarient->unionValues.uInt64Value);
		s = z;
		break;
	case eVT_float:  
		sprintf_s(z,"%10.3f", pEQVarient->unionValues.floatValue);
		s = z;
		break;
	case eVT_double: 
		sprintf_s(z,"%14.3lf", pEQVarient->unionValues.doubleValue);
		s = z;
		break;
	case eVT_asciiString:
		sprintf_s(z,"%s", pEQVarient->eqchar.pChar);
		s = z;
		break;
	case eVT_unicodeString: 
		sprintf_s(z,"%s", pEQVarient->eqchar.pChar);
		s = z;
		break;
	case eVT_short:     
		sprintf_s(z,"%10d", pEQVarient->unionValues.shortValue);
		s = z;
		break;
	case eVT_ushort:     
		sprintf_s(z,"%10u", pEQVarient->unionValues.uShortValue);
		s = z;
		break;

	default:
		break;
	}

	return s;
}
//���ص�����ʾ��
int obtainCallback(const EQMSG* pMsg, LPVOID lpUserParam)
{
	printf("\r\n********obtainCallback*******\r\n");
	//�����ص����⵽��½���߻��ߵ�¼���ߴ����߼�
	if(pMsg && pMsg->msgType == eMT_err)
	{
		if(pMsg->err == EQERR_LOGIN_DISCONNECT || pMsg->err == EQERR_LOGIN_COUNT_LIMIT)
		{
			//��¼����  ����  ��½���ﵽ���ߣ�����¼�������ߣ�
			printf("\r\nYour account is disconnect. err [%d] %s\r\n", pMsg->err, emgeterrstring(pMsg->err, eLang_en));
			//�������ڴ�֪ͨ���߳��˺ŵ����ˣ������߳����µ�½�ͺ����������ˣ������ڴ˴����µ�½Ҳ�ɡ��Ƽ���һ�֡�
			//...do something
		}
	}

	return 0;
}

//ʵʱ����ص�����ʾ��
int csqCallback(const EQMSG* pMsg, LPVOID lpUserParam)
{
	static int times = 1;
	SYSTEMTIME st;
	GetLocalTime(&st);

	printf("****************************************\r\n");
	printf("[%02d:%02d:%02d]Received [%d] callback: msgType=%d, err=%d, requestID=%d, serialID=%d.\r\n", st.wHour, st.wMinute, st.wSecond, times++, pMsg->msgType, pMsg->err, pMsg->requestID, pMsg->serialID);

	if(pMsg->msgType == eMT_err && pMsg->err != EQERR_SUCCESS)
	{
		printf("error %d\r\n", pMsg->err);
		return 0;
	}

	if(!pMsg->pEQData)
	{
		printf("****************************************\r\n");
		return 0;
	}

	EQDATA *pEQData = pMsg->pEQData;
	string slinehead(""), sline("");
	if(pEQData->dateArray.nSize == 1)
	{
		slinehead = pEQData->dateArray.pChArray[0].pChar;
		slinehead += " ";
		for(int i=0;i<pEQData->codeArray.nSize;i++)
		{
			sline += string(pEQData->codeArray.pChArray[i].pChar);
			sline += " ";

			for(int j=0;j<pEQData->indicatorArray.nSize;j++)
			{
				if(i == 0)
				{
					slinehead += string(pEQData->indicatorArray.pChArray[j].pChar);
					slinehead += " ";

					if(j == pEQData->indicatorArray.nSize-1)
					{
						printf("%s\r\n",slinehead.c_str());
					}
				}

				EQVARIENT* pEQVarient = (*pEQData)(i,j,0);
				if(pEQVarient)
				{
					sline += eqvalue2string(pEQVarient);
					sline += " ";
				}
			}
			sline += "\r\n";
		}
		printf("%s",sline.c_str());
	}
	else
	{
		for(int k=0;k<pEQData->dateArray.nSize;k++)
		{
			slinehead = pEQData->dateArray.pChArray[k].pChar;
			sline = "";

			for(int i=0;i<pEQData->codeArray.nSize;i++)
			{
				sline += string(pEQData->codeArray.pChArray[i].pChar);
				sline += " ";

				for(int j=0;j<pEQData->indicatorArray.nSize;j++)
				{
					if(i == 0)
					{
						slinehead += string(pEQData->indicatorArray.pChArray[j].pChar);
						slinehead += " ";

						if(j == pEQData->indicatorArray.nSize-1)
						{
							printf("%s\r\n",slinehead.c_str());
						}
					}

					EQVARIENT* pEQVarient = (*pEQData)(i,j,0);
					if(pEQVarient)
					{
						sline += eqvalue2string(pEQVarient);
						sline += " ";
					}
				}
				sline += "\r\n";
			}

			sline += "\r\n";
			printf("%s",sline.c_str());
		}
	}

	printf("****************************************\r\n");
	return 0;
}

//�������۷���ص�����ʾ������ʾ���ǽ�������ص��ļ������ڹ۲�
int cstCallback(const EQMSG* pMsg, LPVOID lpUserParam)
{
	LPVOID pUser = lpUserParam;

	static char buf[1024] = {0};
	memset(buf, 0, 1024);

	if(!pMsg->pEQData)
	{
		return 0;
	}


	DWORD dw1 = GetTickCount();

	EQDATA *pEQData = pMsg->pEQData;

	if(pEQData->codeArray.nSize != 1)
	{
		return 0;
	}

	memset(buf, 0, 1024);
	sprintf_s(buf,"..\\bin\\%s.txt", pEQData->codeArray.pChArray[0].pChar);
	FILE* fp = fopen(buf, "w+");
	if(!fp)
	{
		return 0;
	}

	memset(buf, 0, 1024);
	int pos = 0;
	for(int j=0;j<pEQData->indicatorArray.nSize;j++)
	{
		sprintf(buf+pos,"%s ", pEQData->indicatorArray.pChArray[j].pChar);
		pos = pos + pEQData->indicatorArray.pChArray[j].nSize;
	}
	sprintf(buf+pos, "%s", "\n");
	fwrite(buf, 1, strlen(buf), fp);

	string slinehead(""), sline("");
	for(int k=0;k<pEQData->dateArray.nSize;k++)
	{
		memset(buf, 0, 1024);
		sline = "";
		for(int j=0;j<pEQData->indicatorArray.nSize;j++)
		{
			EQVARIENT* pEQVarient = (*pEQData)(0,j,k);
			if(pEQVarient)
			{
				sline += eqvalue2string(pEQVarient);
				sline += " ";
			}
		}
		sprintf(buf,"%s\n",sline.c_str());
		fwrite(buf, 1, strlen(buf), fp);
	}

	DWORD dw2 = GetTickCount() - dw1;

	memset(buf, 0, 1024);
	sprintf(buf, "\nthis callback use %d ms\n", dw2);
	fwrite(buf, 1, strlen(buf), fp);
	fclose(fp);

	return 0;
}


int _tmain(int argc, _TCHAR* argv[])
{
	char DllPath[MAX_PATH] = {0};

#ifdef _WIN64  
	strcpy_s(DllPath, "../lib/EmQuantAPI_x64.dll");
#else  
	strcpy_s(DllPath, "../lib/EmQuantAPI.dll");
#endif  

	//����dll��ַ
	HMODULE hDll = LoadLibraryA(DllPath);
	if(hDll == NULL)
	{
		return 0;
	}
	emmanualactivate = (pmanualactivate)GetProcAddress(hDll, "manualactivate");
	emsetproxy = (psetproxy)GetProcAddress(hDll, "setproxy");
	emstart = (pstart)GetProcAddress(hDll, "start");
	emstop = (pstop)GetProcAddress(hDll, "stop");
	emgeterrstring = (pgeterrstring)GetProcAddress(hDll, "geterrstring");
	emcsd = (pcsd)GetProcAddress(hDll, "csd");
	emcss = (pcss)GetProcAddress(hDll, "css");
	emtradedates = (ptradedates)GetProcAddress(hDll, "tradedates");
	emsector = (psector)GetProcAddress(hDll, "sector");
	emgetdate = (pgetdate)GetProcAddress(hDll, "getdate");
	emcsq = (pcsq)GetProcAddress(hDll, "csq");
	emcsqcancel = (pcsqcancel)GetProcAddress(hDll, "csqcancel");
	emreleasedata = (preleasedata)GetProcAddress(hDll, "releasedata");
	emcsc = (pcsc)GetProcAddress(hDll, "csc");
	emcst = (pcst)GetProcAddress(hDll, "cst");
	emctr = (pctr)GetProcAddress(hDll, "ctr");
	emcsqsnapshot = (pcsqsnapshot)GetProcAddress(hDll, "csqsnapshot");
	emcps = (pcps)GetProcAddress(hDll, "cps");
	empquery = (ppquery)GetProcAddress(hDll, "pquery");
	emporder = (pporder)GetProcAddress(hDll, "porder");

	if( !emmanualactivate || !emsetproxy || !emstart || !emstop || !emgeterrstring || !emcsd || !emcss || !emtradedates || !emsector 
		|| !emgetdate || !emcsq || !emcsqcancel || !emreleasedata|| !emcsc || !emcst|| !emctr || !emcsqsnapshot || !emcps || !empquery || !emporder)
	{
		FreeLibrary(hDll);
		printf("GetProcAddress fail. Press enter...\n");
		getchar();
		return 0;
	}

	//��ʼ����������־�ص��Լ���½  option����"TestLatency=0"������������  "TestLatency=1"����������ѡ������(���и����������ٵĹ���)
	//����̬���е���־��ͨ���ص��ӿ�������û���Ŀǰwrite2Log��ֻ�ǽ���־�������Ļ���û����Ը���Ϊд���ļ�
	EQErr error = emstart("TestLatency=0,ForceLogin=1", obtainCallback, "../lib", write2Log, eLog_Debug);
	if(error != EQERR_SUCCESS)
	{
		printf("Login fail [%d] %s. Press enter to continue\n", error, emgeterrstring(error, eLang_en));
		getchar();
		return 0;
	}
	printf("Login success.\n");
	

	printf("I will run test examples after 5 seconds.\n");
	Sleep(5000);
	
	
	string codes = "";
	EQDATA* pData = NULL;
	error = emsector("001004", "2017-12-15", NULL, pData);
	if (error == EQERR_SUCCESS)
	{
		//for (int i = 0; i<pData->codeArray.nSize; i++)
		for (int i = 0; i<pData->codeArray.nSize; i++)
		{
			codes += string(pData->codeArray.pChArray[i].pChar);
			if (i != pData->codeArray.nSize - 1)
				codes += ",";
		}
		emreleasedata(pData);
		pData = NULL;
	}
	
	const char* indicator = "OPEN,CLOSE,HIGH";
	printf("*************csd����*************\n");
	pData = NULL;
	error = emcsd(codes.c_str(), indicator, "2016/01/04", "2016/03/01", "Period=1,Adjustflag=1,Curtype=1,Pricetype=1,Type=2", pData);
	if(error == EQERR_SUCCESS)
	{
		for(int j=0;j<pData->indicatorArray.nSize;j++)
		{
			for(int i=0;i<pData->codeArray.nSize;i++)
			{
				for(int k=0;k<pData->dateArray.nSize;k++)
				{
					printf("%s %s %s : ",pData->indicatorArray.pChArray[j].pChar, pData->dateArray.pChArray[k].pChar, pData->codeArray.pChArray[i].pChar);

					EQVARIENT* pEQVarient = (*pData)(i,j,k);
					if(pEQVarient)
					{
						string s = eqvalue2string(pEQVarient);
						printf("%s\n",s.c_str());
					}
				}
			}
		}
		emreleasedata(pData);
		pData = NULL;
	}

	Sleep(1000);

	getch();

	//�˳�
	emstop();
	FreeLibrary(hDll);

	getch();
	return 0;
}