
# -*- coding:utf-8 -*-

__author__ = 'Administrator'


from EmQuantAPI import *
import pandas


#调用登录函数（激活后使用，不需要用户名密码）
loginResult = c.start("ForceLogin=1")

#sector使用范例
#001004 全部A股板块
code = c.sector("001004", "2017-12-01")
#获取全部A股板块成分在日期区间内容的开收盘价
data = c.csd(code.Codes,"OPEN,CLOSE","2017-11-27","2017-12-01","ispandas=1")
#输出数据到data.csv文件
data.to_csv("data.csv")


